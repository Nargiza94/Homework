public class Main {
    public static void main(String[] args) {

int a = 345;
        System.out.println("Число "+a+" -> "+a/100+", "+a%100/10+", "+a%10);

    }
}