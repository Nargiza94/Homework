public class Main {
    public static void main(String[] args) {
        //Дана длина в метрах.Напишите программу.которая переводит
        //указанное значение в км,мили, футы,и аршины
        //Выведите начальное и конвертирование значение на экран


        double meter=200;
        System.out.println("Километр:"+meter/1000);
        System.out.println("Мили:"+meter*1609);
        System.out.println("футы:"+meter+0.3048);
        System.out.println("аршины:"+meter+0.71);
    }
}