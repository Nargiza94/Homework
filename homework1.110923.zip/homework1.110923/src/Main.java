import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Создать программу ,выводящую на экран ближайшие к 10 из двух чисел
        //записанных в переменные m и n.Числа могут быть как целочисленные так и дробные
        //Например: ввод: M=10.5 N=10.45,Вывод:Число 10.45 ближе к 10

        Scanner scr = new Scanner(System.in);
        double m = 10.5;
        double n = 10.45;
        double resM = Math.abs(m - 10);//0.5
        double resN = Math.abs(10 - n);//0.45
        if (resM < resN) {
            System.out.println("Число" + m + "ближе к 10");
        } else if(resN < resM) {
            System.out.println("Число" + n + "ближе к 10");
        } else {
            System.out.println();
        }

        }

    }