import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        //пользователь вводит, сколько лет он состоит в браке.
        //Программа должна вывести, какая годовщина свадьбы будет у пользователя следущей
        // (бумажная ,ситцевая, чугунная, серебрянная и.д)
        //Не обязательно указывать все годовщины ,достаточно 10-15

        Scanner scr=new Scanner(System.in);
        System.out.println("Сколько лет в браке ? ");
        int number= scr.nextInt();
          switch(number) {
              case 1-> System.out.println("Ситцевая");
              case 2-> System.out.println("Бумажная");
              case 3-> System.out.println("Кожанная");
              case 4-> System.out.println("Льяная");
              case 5-> System.out.println("Деревянная");
              case 6-> System.out.println("Чугунная");
              case 7-> System.out.println("Медная");
              case 8-> System.out.println("Жестьянная");
              case 9-> System.out.println("Фаянсовая");
              case 10-> System.out.println("Оловянная");
              default -> System.out.println(" Извините, дальше не знаю ");

          };
           String weddingName=switch (number){
               case 1-> "Ситцевая";
               case 2-> "Бумажная";
               case 3-> "Кожанная";
               case 4-> "Льяная";
               case 5-> "Деревянная";
               case 6-> "Чугунная";
               case 7-> "Медная";
               case 8-> "Жестьянная";
               case 9-> "Оловянная";
               case 10->"Оловянная";
               default -> " Извините, дальше не знаю ";

           };




    }
}