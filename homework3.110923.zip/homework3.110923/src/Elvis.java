import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        //Элвис Пресли жил с 1935 по 1977 год. Используя тернарные операторы, напишите
        //программу, в которой пользователь вводит год. Если указанный год меньше 1935, то
        //вывести «Элвис ещё не родился». Если указанный пользователем год с 1935 по 1977
        //включительно, то вывести «Элвис жив!». Если введённый пользователем год больше 1977,
        //то вывести «Элвис навсегда в наших сердцах!»


        System.out.println("Введит год");
        Scanner scr =new Scanner(System.in);
        int year= scr.nextInt();

        if(year<1935){
            System.out.println("Он еще не родился");
        }
        else{
            if(year<=1977)
                System.out.println("Он жив");
            else
                System.out.println("Элвис навсегда в наших сердцах");

        }
        String str=year<1935?"он еще не родился":(year<=1977?"Он жив":"Элвис навсегда в наших сердцах");
        System.out.println(str);

    }
}