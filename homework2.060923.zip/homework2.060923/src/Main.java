import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Пользователь продавец вводит суммарную стоимость покупок и сумму денег
        //которую дал покупатель.Выводить сумму сдачи в виде
        //"X рублей и  Y копеек".

        Scanner scr= new Scanner(System.in);
        System.out.println("Введите стоимост товара");
        double price= scr.nextDouble();
        System.out.println(" Введите количество денег ");
        double money= scr.nextDouble();
        double change=money-price;//10.25$
        int dollar=(int)change;
        int cent=(int)(change*100)%100;
        System.out.print(dollar+" сдачи рублей:"+ " сдачи копеек "+ cent);

    }
}