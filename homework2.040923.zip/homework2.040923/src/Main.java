import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner  scanner=new Scanner(System.in);
        System.out.print("Доброго времени суток,введите ваша имя");
        String name=scanner.nextLine();
        System.out.println(name+","+"сколько вам лет");
        int age= scanner.nextInt();
        System.out.print("Скажите,пожалуйста,сколько у вас вес");
        double weight= scanner.nextDouble();
        System.out.print("Уважаемый"+name+","+"свои+ age+лет.Вы для нас дорога,как"+weight+"килограмм чистого золота");
    }
}