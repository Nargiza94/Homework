public class Main {
    public static void main(String[] args) {

        byte myByte = 4;
        char myLetter = 'G';
        int myNum = 89;
        short myshort = 56;
        float myFloatNum = 4.7333436F;
        double mydouble = 4.355453532;
        long myLong = 12121l ;
        System.out.println(myByte);
        System.out.println(myLetter);
        System.out.println(myNum);
        System.out.println(myshort);
        System.out.println(myFloatNum);
        System.out.println(mydouble);
        System.out.println(myLong);



    }
}