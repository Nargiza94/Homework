public class Main {
    public static void main(String[] args) {

        boolean isYearFinished=true;
        boolean isGoodWeather=true;
        boolean hasBoughtRaincoats=true;
        boolean isJimFree=true;
        boolean hasKateComeBack=false;
        boolean isHikeHappened=(isGoodWeather||hasBoughtRaincoats) && (isJimFree && hasKateComeBack);
        System.out.println(isHikeHappened);

    }
}