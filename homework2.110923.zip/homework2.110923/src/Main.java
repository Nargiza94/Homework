import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ScheduledExecutorService;

public class Main {
    public static void main(String[] args) {
        //Необходимо написать программу которая проверяет пользователья на знание таблицы умножения
        //Пользователь сам вводит два целых однозначных числа
        //Программа задаёт вопрос: результат умножения первого числа на второе.
        //Пользователь должен ввести ответ и увидеть на экране правильно он ответил
        //или нет. Если пользователь ответил неправильно, то программа должна
        //показать правильный ответ

        Random rnd = new Random();
        int num1 = rnd.nextInt(10);
        int num2 = rnd.nextInt(10);
        System.out.println("Каков резултат умножения  " + num1 + " на " + num2 + "?");
        int user = new Scanner(System.in).nextInt();
        if (num1 * num2 == user) {
            System.out.println(user + "Правильно");
        } else {
            System.out.println("Не правильно: Правилный ответ:" + num1 * num2);
        }


    }


}
