import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scr= new Scanner(System.in);
        System.out.println("Ввелите число");
        int x= scr.nextInt();
        System.out.println("половина числа "+x);
        System.out.println(x>>1);

    }
}