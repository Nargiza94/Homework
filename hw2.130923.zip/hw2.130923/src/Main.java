import object.Games;

import java.util.Objects;
import java.util.Random;
import java.util.Scanner;
import java.util.Stack;

public class Main {
    public static void main(String[] args) {
        //Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит
        //свой выбор (в виде строки или числа). Программа случайным образом делает
        //свой выбор и выводит на экран. Далее программа показывает, кто победитель –
        //пользователь или программа.


        System.out.println("Добро пожаловать в игру: Камень, ножницы , бумага");
        Scanner scr=new Scanner(System.in);
        System.out.println("Набери PAPER,SCISSORS или STONE:");
        String name=scr.nextLine().toUpperCase();
        Games userTurn= Games.valueOf(name);

        Random rnd=new Random();
        int compNumber=rnd.nextInt(0,3);
        Games compTurn= switch (compNumber){
            case 0->Games.PAPER;
            case 1->Games.SCISSORS;
            default -> Games.STONE;

        };
        System.out.println(compTurn);
        if (compTurn==userTurn){
            System.out.println("Ничья");
        }else{
            if (userTurn==Games.PAPER&&compTurn==Games.STONE||userTurn==Games.STONE&&compTurn==Games.SCISSORS||
            userTurn==Games.SCISSORS&&compTurn==Games.PAPER){
                System.out.println("Ты победил");
            }else{
                System.out.println("Ты проиграл");
            }
        }



    }
}