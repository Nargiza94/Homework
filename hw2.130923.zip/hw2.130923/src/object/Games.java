package object;

public enum Games {
    PAPER,
    SCISSORS,
    STONE
}
